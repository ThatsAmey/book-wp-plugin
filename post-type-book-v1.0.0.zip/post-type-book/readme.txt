=== Book Plugin ===
Contributors: amey
Tags: books, post-type
Requires at least: 4.0
Tested up to: 6.6.2
Stable tag: 1.0.0
Requires PHP: 5.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A custom post type for Books.

== Description ==

A simple plugin nothing special.


== Changelog ==

= 1.0.0 =
* Initial release.
